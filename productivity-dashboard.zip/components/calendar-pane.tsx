"use client"

import { useState } from "react"
import { CalendarIcon, Clock, Users, ChevronLeft, ChevronRight, Plus } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

// Mock calendar data
const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

interface CalendarEvent {
  id: number
  title: string
  start: Date
  end: Date
  type: "meeting" | "task" | "reminder"
  participants?: string[]
  location?: string
  isTaskRelated?: boolean
  relatedTaskId?: number
  color?: string
}

// Mock events data
const mockEvents: CalendarEvent[] = [
  {
    id: 1,
    title: "Team Standup",
    start: new Date(new Date().setHours(10, 0, 0, 0)),
    end: new Date(new Date().setHours(10, 30, 0, 0)),
    type: "meeting",
    participants: ["John Doe", "Sarah Smith", "Alex Johnson"],
    location: "Zoom",
    color: "bg-blue-500",
  },
  {
    id: 2,
    title: "Project Review",
    start: new Date(new Date().setHours(13, 0, 0, 0)),
    end: new Date(new Date().setHours(14, 0, 0, 0)),
    type: "meeting",
    participants: ["Marketing Team"],
    location: "Conference Room A",
    color: "bg-purple-500",
  },
  {
    id: 3,
    title: "Complete Proposal",
    start: new Date(new Date().setHours(15, 0, 0, 0)),
    end: new Date(new Date().setHours(16, 30, 0, 0)),
    type: "task",
    isTaskRelated: true,
    relatedTaskId: 101,
    color: "bg-amber-500",
  },
  {
    id: 4,
    title: "Send Follow-up Email",
    start: new Date(new Date().setHours(17, 0, 0, 0)),
    end: new Date(new Date().setHours(17, 15, 0, 0)),
    type: "reminder",
    isTaskRelated: true,
    relatedTaskId: 102,
    color: "bg-green-500",
  },
]

export default function CalendarPane() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [events, setEvents] = useState<CalendarEvent[]>(mockEvents)

  // Get current month and year
  const currentMonth = currentDate.getMonth()
  const currentYear = currentDate.getFullYear()

  // Navigate to previous/next day
  const goToPreviousDay = () => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() - 1)
    setCurrentDate(newDate)
  }

  const goToNextDay = () => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() + 1)
    setCurrentDate(newDate)
  }

  // Get today's events
  const todaysEvents = events
    .filter(
      (event) =>
        event.start.getDate() === currentDate.getDate() &&
        event.start.getMonth() === currentDate.getMonth() &&
        event.start.getFullYear() === currentDate.getFullYear(),
    )
    .sort((a, b) => a.start.getTime() - b.start.getTime())

  // Format time (e.g., "10:00 AM")
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Get event type badge
  const getEventTypeBadge = (type: string) => {
    switch (type) {
      case "meeting":
        return <Badge className="bg-blue-500">Meeting</Badge>
      case "task":
        return <Badge className="bg-amber-500">Task</Badge>
      case "reminder":
        return <Badge className="bg-green-500">Reminder</Badge>
      default:
        return null
    }
  }

  return (
    <Card className="h-full border-0 shadow-none bg-transparent">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <div className="bg-primary/10 dark:bg-primary/20 p-2 rounded-full mr-3">
              <CalendarIcon className="h-5 w-5 text-primary dark:text-primary" />
            </div>
            Calendar
          </CardTitle>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="icon" onClick={goToPreviousDay} className="h-8 w-8 rounded-full">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="h-8 px-2 text-xs" onClick={() => setCurrentDate(new Date())}>
              Today
            </Button>
            <Button variant="ghost" size="icon" onClick={goToNextDay} className="h-8 w-8 rounded-full">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <CardDescription>
          {DAYS[currentDate.getDay()]}, {MONTHS[currentMonth]} {currentDate.getDate()}, {currentYear}
        </CardDescription>
      </CardHeader>
      <CardContent className="overflow-auto h-[calc(100%-100px)]">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-medium">Today's Schedule</h3>
          <Button variant="outline" size="sm" className="h-8 rounded-full gap-1">
            <Plus className="h-3 w-3" />
            Add Event
          </Button>
        </div>

        {todaysEvents.length > 0 ? (
          <div className="space-y-3">
            {todaysEvents.map((event) => (
              <div
                key={event.id}
                className={`p-3 border rounded-lg hover:bg-accent/50 transition-all duration-200 cursor-pointer ${event.isTaskRelated ? "border-l-4 border-l-amber-500" : ""}`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium">{event.title}</h4>
                    <div className="flex items-center text-xs text-muted-foreground mt-1 space-x-3">
                      <span className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {formatTime(event.start)} - {formatTime(event.end)}
                      </span>
                      {event.location && <span>{event.location}</span>}
                    </div>
                  </div>
                  {getEventTypeBadge(event.type)}
                </div>

                {event.participants && event.participants.length > 0 && (
                  <div className="mt-2">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Users className="h-3 w-3 mr-1" />
                      <span>{event.participants.length} participants</span>
                    </div>
                    <div className="flex -space-x-2 mt-1">
                      {event.participants.slice(0, 3).map((participant, index) => (
                        <Avatar key={index} className="h-6 w-6 border-2 border-background">
                          <AvatarFallback className="text-[10px]">
                            {participant
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                      ))}
                      {event.participants.length > 3 && (
                        <div className="flex items-center justify-center h-6 w-6 rounded-full bg-muted text-[10px] border-2 border-background">
                          +{event.participants.length - 3}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {event.isTaskRelated && (
                  <Badge variant="outline" className="mt-2 text-xs">
                    From extracted task
                  </Badge>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 text-center text-muted-foreground">
            <div className="bg-primary/10 dark:bg-primary/20 p-3 rounded-full mb-2">
              <CalendarIcon className="h-6 w-6 text-primary dark:text-primary opacity-70" />
            </div>
            <p>No events scheduled for today</p>
            <Button variant="link" size="sm" className="mt-1">
              Add your first event
            </Button>
          </div>
        )}

        <div className="mt-6">
          <h3 className="text-sm font-medium mb-3">Upcoming Tasks</h3>
          <div className="space-y-2">
            <div className="p-2 border rounded-md bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-sm font-medium">Send report by Friday</h4>
                  <p className="text-xs text-muted-foreground">Extracted from email from John Doe</p>
                </div>
                <Badge className="bg-amber-500">Due in 2 days</Badge>
              </div>
            </div>
            <div className="p-2 border rounded-md bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-sm font-medium">Review proposal document</h4>
                  <p className="text-xs text-muted-foreground">Requested by Sarah Smith</p>
                </div>
                <Badge className="bg-blue-500">Due tomorrow</Badge>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

