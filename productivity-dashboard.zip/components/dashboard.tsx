"use client"

import { useState } from "react"
import { MoonIcon, SunIcon } from "lucide-react"
import { useTheme } from "next-themes"
import EmailPane from "@/components/email-pane"
import NewsPane from "@/components/news-pane"
import NotesPane from "@/components/notes-pane"
import CalendarPane from "@/components/calendar-pane"
import { Button } from "@/components/ui/button"

export default function Dashboard() {
  const [newsCategory, setNewsCategory] = useState("sports")
  const { theme, setTheme } = useTheme()

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 dark:from-background dark:to-slate-900/20">
      <div className="container mx-auto p-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-600 dark:from-blue-400 dark:to-purple-400 text-transparent bg-clip-text">
              Sidekick
            </h1>
            <p className="text-muted-foreground text-sm mt-1">Your daily productivity companion</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="rounded-full"
          >
            {theme === "dark" ? <SunIcon className="h-5 w-5" /> : <MoonIcon className="h-5 w-5" />}
          </Button>
        </div>

        {/* Updated grid layout with calendar pane */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-6 md:grid-rows-6 md:h-[900px]">
          {/* Email pane - slightly smaller to make room for calendar */}
          <div className="h-[400px] md:h-auto md:col-span-3 md:row-span-3 rounded-xl overflow-hidden border border-border/40 bg-card/80 backdrop-blur-sm shadow-lg transition-all duration-300 hover:shadow-xl">
            <EmailPane />
          </div>

          {/* Calendar pane - new addition */}
          <div className="h-[400px] md:h-auto md:col-span-3 md:row-span-3 rounded-xl overflow-hidden border border-border/40 bg-card/80 backdrop-blur-sm shadow-lg transition-all duration-300 hover:shadow-xl">
            <CalendarPane />
          </div>

          {/* News pane */}
          <div className="h-[350px] md:h-auto md:col-span-3 md:row-span-3 rounded-xl overflow-hidden border border-border/40 bg-card/80 backdrop-blur-sm shadow-lg transition-all duration-300 hover:shadow-xl">
            <NewsPane category={newsCategory} onCategoryChange={setNewsCategory} />
          </div>

          {/* Notes pane */}
          <div className="h-[350px] md:h-auto md:col-span-3 md:row-span-3 rounded-xl overflow-hidden border border-border/40 bg-card/80 backdrop-blur-sm shadow-lg transition-all duration-300 hover:shadow-xl">
            <NotesPane />
          </div>
        </div>

        <footer className="mt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Sidekick Assistant. All rights reserved.</p>
        </footer>
      </div>
    </div>
  )
}

