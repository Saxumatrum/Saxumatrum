"use client"

import { useState, useEffect } from "react"
import { StickyNote, Plus, Save, Trash, PenLine, Calendar, Tag, Clock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface Note {
  id: number
  title: string
  content: string
  date: string
  category?: string
  color?: string
}

const noteCategories = [
  { name: "Work", color: "bg-blue-500" },
  { name: "Personal", color: "bg-green-500" },
  { name: "Ideas", color: "bg-purple-500" },
  { name: "Tasks", color: "bg-amber-500" },
]

export default function NotesPane() {
  const [notes, setNotes] = useState<Note[]>([])
  const [currentNote, setCurrentNote] = useState<Note | null>(null)
  const [isEditing, setIsEditing] = useState(false)

  // Load notes from localStorage on component mount
  useEffect(() => {
    const savedNotes = localStorage.getItem("productivityNotes")
    if (savedNotes) {
      try {
        setNotes(JSON.parse(savedNotes))
      } catch (e) {
        console.error("Failed to parse notes from localStorage")
      }
    }
  }, [])

  // Save notes to localStorage when they change
  useEffect(() => {
    if (notes.length > 0) {
      localStorage.setItem("productivityNotes", JSON.stringify(notes))
    }
  }, [notes])

  const createNewNote = () => {
    const randomCategory = noteCategories[Math.floor(Math.random() * noteCategories.length)]
    const newNote = {
      id: Date.now(),
      title: "",
      content: "",
      date: new Date().toLocaleString(),
      category: randomCategory.name,
      color: randomCategory.color,
    }
    setCurrentNote(newNote)
    setIsEditing(true)
  }

  const saveNote = () => {
    if (currentNote && (currentNote.title.trim() || currentNote.content.trim())) {
      const isExisting = notes.some((note) => note.id === currentNote.id)

      if (isExisting) {
        setNotes(notes.map((note) => (note.id === currentNote.id ? currentNote : note)))
      } else {
        setNotes([currentNote, ...notes])
      }

      setIsEditing(false)
    }
  }

  const deleteNote = (id: number) => {
    setNotes(notes.filter((note) => note.id !== id))
    if (currentNote && currentNote.id === id) {
      setCurrentNote(null)
      setIsEditing(false)
    }
  }

  const editNote = (note: Note) => {
    setCurrentNote(note)
    setIsEditing(true)
  }

  const updateNoteCategory = (category: string) => {
    if (currentNote) {
      const categoryObj = noteCategories.find((cat) => cat.name === category)
      setCurrentNote({
        ...currentNote,
        category,
        color: categoryObj?.color,
      })
    }
  }

  return (
    <Card className="h-full border-0 shadow-none bg-transparent">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <div className="bg-primary/10 dark:bg-primary/20 p-2 rounded-full mr-3">
              <StickyNote className="h-5 w-5 text-primary dark:text-primary" />
            </div>
            Quick Notes
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={createNewNote}
            className="rounded-full gap-1 hover:bg-primary/10 hover:text-primary"
          >
            <Plus className="h-4 w-4" />
            New Note
          </Button>
        </div>
        <CardDescription>Capture ideas and tasks</CardDescription>
      </CardHeader>
      <CardContent className="overflow-auto h-[calc(100%-100px)]">
        {isEditing ? (
          <div className="space-y-3 animate-in fade-in-50 duration-300">
            <div className="flex items-center gap-2">
              <PenLine className="h-4 w-4 text-muted-foreground" />
              <Input
                value={currentNote?.title || ""}
                onChange={(e) => setCurrentNote((prev) => (prev ? { ...prev, title: e.target.value } : null))}
                placeholder="Note title"
                className="border-none bg-muted/50 focus-visible:ring-0 focus-visible:ring-offset-0"
              />
            </div>
            <Textarea
              value={currentNote?.content || ""}
              onChange={(e) => setCurrentNote((prev) => (prev ? { ...prev, content: e.target.value } : null))}
              placeholder="Write your note here..."
              className="min-h-[120px] border-none bg-muted/50 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              <span>{new Date().toLocaleDateString()}</span>
              <Clock className="h-3 w-3 ml-2" />
              <span>{new Date().toLocaleTimeString()}</span>
            </div>
            <div className="flex items-center gap-2">
              <Tag className="h-4 w-4 text-muted-foreground" />
              <div className="flex gap-1">
                {noteCategories.map((category) => (
                  <Badge
                    key={category.name}
                    variant={currentNote?.category === category.name ? "default" : "outline"}
                    className={`cursor-pointer ${currentNote?.category === category.name ? category.color : ""}`}
                    onClick={() => updateNoteCategory(category.name)}
                  >
                    {category.name}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="flex justify-end space-x-2 mt-2">
              <Button variant="outline" size="sm" onClick={() => setIsEditing(false)} className="rounded-full">
                Cancel
              </Button>
              <Button size="sm" onClick={saveNote} className="rounded-full gap-1">
                <Save className="h-4 w-4" />
                Save
              </Button>
            </div>
          </div>
        ) : (
          <div className="h-full overflow-auto">
            {notes.length > 0 ? (
              <div className="grid grid-cols-1 gap-3">
                {notes.map((note) => (
                  <div
                    key={note.id}
                    className="p-3 border rounded-lg hover:bg-accent/50 cursor-pointer transition-all duration-200 hover:shadow-md group"
                    onClick={() => editNote(note)}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        {note.title && <h3 className="font-medium mb-1">{note.title}</h3>}
                        <p className="text-sm line-clamp-2">{note.content}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 ml-2 -mt-1 -mr-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                        onClick={(e) => {
                          e.stopPropagation()
                          deleteNote(note.id)
                        }}
                      >
                        <Trash className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <Badge variant="secondary" className={`text-xs ${note.color}`}>
                        {note.category}
                      </Badge>
                      <p className="text-xs text-muted-foreground">{note.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                <div className="bg-primary/10 dark:bg-primary/20 p-4 rounded-full mb-3">
                  <StickyNote className="h-8 w-8 text-primary dark:text-primary opacity-70" />
                </div>
                <p>No notes yet</p>
                <Button variant="link" size="sm" onClick={createNewNote} className="mt-1">
                  Create your first note
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

