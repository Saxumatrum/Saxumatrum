"use client"

import { useState, useEffect } from "react"
import { Newspaper, RefreshCw, ExternalLink, ThumbsUp, MessageSquare, Share2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"

// Mock news data - in a real app, this would come from a news API
const mockNews = {
  sports: [
    {
      id: 1,
      title: "Lakers win championship in dramatic fashion",
      source: "Sports News",
      time: "2 hours ago",
      image: "/placeholder.svg?height=80&width=120",
      likes: 245,
      comments: 58,
    },
    {
      id: 2,
      title: "Tennis star advances to semifinals",
      source: "Tennis Today",
      time: "5 hours ago",
      image: "/placeholder.svg?height=80&width=120",
      likes: 132,
      comments: 27,
    },
    {
      id: 3,
      title: "New record set at marathon event",
      source: "Running Weekly",
      time: "Yesterday",
      image: "/placeholder.svg?height=80&width=120",
      likes: 98,
      comments: 15,
    },
  ],
  technology: [
    {
      id: 1,
      title: "New smartphone announced with revolutionary features",
      source: "Tech Today",
      time: "1 hour ago",
      image: "/placeholder.svg?height=80&width=120",
      likes: 312,
      comments: 87,
    },
    {
      id: 2,
      title: "Major software update brings AI capabilities",
      source: "Software News",
      time: "3 hours ago",
      image: "/placeholder.svg?height=80&width=120",
      likes: 178,
      comments: 42,
    },
    {
      id: 3,
      title: "Startup raises $50M for quantum computing research",
      source: "Venture Beat",
      time: "Yesterday",
      image: "/placeholder.svg?height=80&width=120",
      likes: 203,
      comments: 31,
    },
  ],
  business: [
    {
      id: 1,
      title: "Stock market reaches all-time high",
      source: "Financial Times",
      time: "30 minutes ago",
      image: "/placeholder.svg?height=80&width=120",
      likes: 156,
      comments: 48,
    },
    {
      id: 2,
      title: "Major merger announced between tech giants",
      source: "Business Insider",
      time: "4 hours ago",
      image: "/placeholder.svg?height=80&width=120",
      likes: 224,
      comments: 63,
    },
    {
      id: 3,
      title: "New economic policy expected to boost growth",
      source: "Economy News",
      time: "Yesterday",
      image: "/placeholder.svg?height=80&width=120",
      likes: 87,
      comments: 29,
    },
  ],
}

interface NewsItem {
  id: number
  title: string
  source: string
  time: string
  image: string
  likes: number
  comments: number
}

interface NewsPaneProps {
  category: string
  onCategoryChange: (category: string) => void
}

export default function NewsPane({ category, onCategoryChange }: NewsPaneProps) {
  const [loading, setLoading] = useState(false)
  const [news, setNews] = useState<NewsItem[]>([])

  useEffect(() => {
    loadNews(category)
  }, [category])

  const loadNews = (cat: string) => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      setNews(mockNews[cat as keyof typeof mockNews] || [])
      setLoading(false)
    }, 800)
  }

  const refreshNews = () => {
    loadNews(category)
  }

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case "sports":
        return "bg-emerald-500"
      case "technology":
        return "bg-blue-500"
      case "business":
        return "bg-amber-500"
      default:
        return "bg-primary"
    }
  }

  return (
    <Card className="h-full border-0 shadow-none bg-transparent">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <div className="bg-primary/10 dark:bg-primary/20 p-2 rounded-full mr-3">
              <Newspaper className="h-5 w-5 text-primary dark:text-primary" />
            </div>
            News Feed
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={refreshNews} className="rounded-full hover:bg-primary/10">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
        <CardDescription>Stay updated with the latest news</CardDescription>
        <div className="flex items-center justify-between mt-2">
          <Badge className={`${getCategoryColor(category)}`}>
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </Badge>
          <Select value={category} onValueChange={onCategoryChange}>
            <SelectTrigger className="w-[140px] h-8">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sports">Sports</SelectItem>
              <SelectItem value="technology">Technology</SelectItem>
              <SelectItem value="business">Business</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="overflow-auto h-[calc(100%-140px)]">
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex space-x-3">
                <Skeleton className="h-20 w-20 rounded-md" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <div className="flex justify-between">
                    <Skeleton className="h-3 w-20" />
                    <Skeleton className="h-3 w-16" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {news.map((item) => (
              <div
                key={item.id}
                className="flex space-x-3 p-2 rounded-lg hover:bg-accent/50 transition-colors duration-200"
              >
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.title}
                  className="h-20 w-20 object-cover rounded-md"
                />
                <div className="flex-1">
                  <h4 className="font-medium line-clamp-2">{item.title}</h4>
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>{item.source}</span>
                    <span>{item.time}</span>
                  </div>
                  <div className="flex mt-2 justify-between">
                    <div className="flex space-x-3 text-xs text-muted-foreground">
                      <span className="flex items-center">
                        <ThumbsUp className="h-3 w-3 mr-1" />
                        {item.likes}
                      </span>
                      <span className="flex items-center">
                        <MessageSquare className="h-3 w-3 mr-1" />
                        {item.comments}
                      </span>
                    </div>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 rounded-full hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-blue-900/30"
                      >
                        <Share2 className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 rounded-full hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-blue-900/30"
                      >
                        <ExternalLink className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

