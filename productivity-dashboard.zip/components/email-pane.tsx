"use client"

import { useState } from "react"
import {
  Check,
  Clock,
  Mail,
  Star,
  MoreHorizontal,
  Filter,
  Calendar,
  AlertCircle,
  UserPlus,
  ArrowRight,
  CheckCircle2,
  Brain,
  Sparkles,
  RefreshCw,
  Info,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Update the mockEmails to include extracted tasks and commitments
const mockEmails = [
  {
    id: 1,
    from: "John Doe",
    email: "john.doe@example.com",
    subject: "Project Update",
    preview:
      "Here's the latest update on the project. We've made significant progress on the frontend development and are on track to meet our deadline. I'll send the full report by Friday.",
    time: "10:30",
    needsReply: true,
    hasTasks: true,
    completed: false,
    priority: "high",
    avatar: "/placeholder.svg?height=32&width=32",
    extractedTasks: [
      {
        id: 101,
        text: "Send full report by Friday",
        type: "commitment",
        dueDate: "Friday",
        suggestedTime: "Thursday, 2:00 PM",
        status: "pending",
        confidence: 0.92,
        extractionMethod: "llm",
      },
    ],
  },
  {
    id: 2,
    from: "Sarah Smith",
    email: "sarah.smith@example.com",
    subject: "Meeting Tomorrow",
    preview:
      "Can we schedule a meeting tomorrow at 2 PM? I'd like to discuss the marketing strategy for our new product launch. Also, can you please review the proposal I sent last week?",
    time: "Yesterday",
    needsReply: true,
    hasTasks: false,
    completed: false,
    priority: "medium",
    avatar: "/placeholder.svg?height=32&width=32",
    extractedTasks: [
      {
        id: 102,
        text: "Review proposal document",
        type: "request",
        dueDate: "ASAP",
        suggestedTime: "Today, 4:00 PM",
        status: "pending",
        confidence: 0.88,
        extractionMethod: "llm",
      },
      {
        id: 103,
        text: "Attend meeting about marketing strategy",
        type: "meeting",
        dueDate: "Tomorrow, 2:00 PM",
        suggestedTime: "Tomorrow, 2:00 PM",
        status: "scheduled",
        addedToCalendar: true,
        confidence: 0.95,
        extractionMethod: "llm",
      },
    ],
  },
  {
    id: 3,
    from: "Marketing Team",
    email: "marketing@company.com",
    subject: "Campaign Results",
    preview:
      "The results from our latest campaign are in. We've seen a 25% increase in engagement and a 15% increase in conversions.",
    time: "2 days ago",
    needsReply: false,
    hasTasks: true,
    completed: true,
    priority: "low",
    avatar: "/placeholder.svg?height=32&width=32",
    extractedTasks: [],
  },
  {
    id: 4,
    from: "Alex Johnson",
    email: "alex.j@example.com",
    subject: "Product Feedback",
    preview:
      "I've been using the new feature and have some feedback. Overall, it's great but there are a few usability issues I'd like to discuss. Let's meet next week to go over them in detail.",
    time: "3 days ago",
    needsReply: true,
    hasTasks: false,
    completed: false,
    priority: "medium",
    avatar: "/placeholder.svg?height=32&width=32",
    extractedTasks: [
      {
        id: 104,
        text: "Schedule meeting about product feedback",
        type: "action",
        dueDate: "Next week",
        suggestedTime: "Monday, 11:00 AM",
        status: "pending",
        confidence: 0.85,
        extractionMethod: "llm",
      },
    ],
  },
]

// Add a new interface for extracted tasks
interface ExtractedTask {
  id: number
  text: string
  type: "commitment" | "request" | "meeting" | "action" | "follow-up"
  dueDate: string
  suggestedTime?: string
  status: "pending" | "scheduled" | "completed" | "delegated"
  assignedTo?: string
  addedToCalendar?: boolean
  confidence?: number
  extractionMethod?: string
}

// Update the email pane component
export default function EmailPane() {
  const [emails, setEmails] = useState(mockEmails)
  const [filter, setFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("pending")
  const [isProcessing, setIsProcessing] = useState(false)
  const [showLLMInfo, setShowLLMInfo] = useState(false)

  const markAsCompleted = (id: number) => {
    setEmails(emails.map((email) => (email.id === id ? { ...email, completed: true } : email)))
  }

  const pendingEmails = emails.filter((email) => !email.completed && (email.needsReply || email.hasTasks))
  const completedEmails = emails.filter((email) => email.completed)

  const filteredPendingEmails =
    filter === "all" ? pendingEmails : pendingEmails.filter((email) => email.priority === filter)

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-500 border-red-500"
      case "medium":
        return "text-amber-500 border-amber-500"
      case "low":
        return "text-green-500 border-green-500"
      default:
        return ""
    }
  }

  const getTaskTypeIcon = (type: string) => {
    switch (type) {
      case "commitment":
        return <CheckCircle2 className="h-3 w-3 mr-1 text-blue-500" />
      case "request":
        return <AlertCircle className="h-3 w-3 mr-1 text-amber-500" />
      case "meeting":
        return <Calendar className="h-3 w-3 mr-1 text-purple-500" />
      case "action":
        return <ArrowRight className="h-3 w-3 mr-1 text-green-500" />
      case "follow-up":
        return <Clock className="h-3 w-3 mr-1 text-red-500" />
      default:
        return <Clock className="h-3 w-3 mr-1" />
    }
  }

  const completeTask = (emailId: number, taskId: number) => {
    setEmails(
      emails.map((email) => {
        if (email.id === emailId) {
          const updatedTasks = email.extractedTasks.map((task) =>
            task.id === taskId ? { ...task, status: "completed" } : task,
          )
          return { ...email, extractedTasks: updatedTasks }
        }
        return email
      }),
    )
  }

  const scheduleTask = (emailId: number, taskId: number) => {
    setEmails(
      emails.map((email) => {
        if (email.id === emailId) {
          const updatedTasks = email.extractedTasks.map((task) =>
            task.id === taskId ? { ...task, status: "scheduled", addedToCalendar: true } : task,
          )
          return { ...email, extractedTasks: updatedTasks }
        }
        return email
      }),
    )
  }

  const delegateTask = (emailId: number, taskId: number, assignee = "Team Member") => {
    setEmails(
      emails.map((email) => {
        if (email.id === emailId) {
          const updatedTasks = email.extractedTasks.map((task) =>
            task.id === taskId ? { ...task, status: "delegated", assignedTo: assignee } : task,
          )
          return { ...email, extractedTasks: updatedTasks }
        }
        return email
      }),
    )
  }

  // Get all extracted tasks across all emails
  const allExtractedTasks = emails.flatMap((email) =>
    email.extractedTasks.map((task) => ({
      ...task,
      emailFrom: email.from,
      emailSubject: email.subject,
      emailId: email.id,
    })),
  )

  const pendingTasks = allExtractedTasks.filter((task) => task.status === "pending")
  const scheduledTasks = allExtractedTasks.filter((task) => task.status === "scheduled")
  const completedTasks = allExtractedTasks.filter((task) => task.status === "completed")
  const delegatedTasks = allExtractedTasks.filter((task) => task.status === "delegated")

  // Simulate LLM processing
  const processEmailsWithLLM = () => {
    setIsProcessing(true)
    // Simulate API call to LLM
    setTimeout(() => {
      setIsProcessing(false)
    }, 2000)
  }

  return (
    <Card className="h-full border-0 shadow-none bg-transparent">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <CardTitle className="flex items-center">
              <div className="bg-primary/10 dark:bg-primary/20 p-2 rounded-full mr-3">
                <Mail className="h-5 w-5 text-primary dark:text-primary" />
              </div>
              Email Tracker
            </CardTitle>
            <Dialog open={showLLMInfo} onOpenChange={setShowLLMInfo}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="ml-1 h-6 w-6 rounded-full">
                  <Info className="h-3.5 w-3.5" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="flex items-center">
                    <Brain className="mr-2 h-5 w-5 text-purple-500" />
                    LLM-Powered Task Extraction
                  </DialogTitle>
                  <DialogDescription>
                    How our AI analyzes your emails to identify tasks and commitments
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-2">
                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium flex items-center mb-2">
                      <Sparkles className="h-4 w-4 mr-2 text-amber-500" />
                      Natural Language Understanding
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Our system uses a Large Language Model (LLM) to analyze the content of your emails and identify
                      commitments, requests, and action items using advanced natural language understanding.
                    </p>
                  </div>

                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium flex items-center mb-2">
                      <CheckCircle2 className="h-4 w-4 mr-2 text-green-500" />
                      What It Identifies
                    </h4>
                    <ul className="text-sm text-muted-foreground space-y-1 ml-6 list-disc">
                      <li>Commitments you've made ("I'll send that report by Friday")</li>
                      <li>Requests from others ("Can you review this proposal?")</li>
                      <li>Meeting invitations and scheduling requests</li>
                      <li>Follow-up reminders and deadlines</li>
                      <li>Delegation opportunities</li>
                    </ul>
                  </div>

                  <div className="rounded-lg border p-3">
                    <h4 className="font-medium flex items-center mb-2">
                      <Calendar className="h-4 w-4 mr-2 text-blue-500" />
                      Smart Scheduling
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      The system suggests optimal times to complete tasks based on your calendar availability, task
                      complexity, and urgency. It can automatically add events to your calendar.
                    </p>
                  </div>

                  <div className="rounded-lg border p-3 bg-muted/30">
                    <h4 className="font-medium flex items-center mb-2">
                      <AlertCircle className="h-4 w-4 mr-2 text-red-500" />
                      Privacy Note
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      All email processing happens securely on our servers. Email content is never stored permanently
                      and is only used for task extraction.
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <div className="flex items-center space-x-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={processEmailsWithLLM}
                    disabled={isProcessing}
                    className="h-8 rounded-full text-xs gap-1"
                  >
                    <Brain className="h-3.5 w-3.5 text-purple-500" />
                    {isProcessing ? (
                      <>
                        <RefreshCw className="h-3 w-3 animate-spin" />
                        Processing
                      </>
                    ) : (
                      "Process New Emails"
                    )}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Use LLM to analyze emails and extract tasks</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Filter className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setFilter("all")}>All Priorities</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilter("high")}>High Priority</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilter("medium")}>Medium Priority</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilter("low")}>Low Priority</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        <CardDescription className="flex items-center">
          Track emails that need replies and tasks
          {isProcessing && (
            <Badge variant="outline" className="ml-2 text-xs animate-pulse">
              <Brain className="h-3 w-3 mr-1 text-purple-500" />
              LLM analyzing emails...
            </Badge>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="overflow-auto h-[calc(100%-100px)]">
        <Tabs defaultValue="pending" className="w-full" onValueChange={setActiveTab} value={activeTab}>
          <TabsList className="grid grid-cols-2 mb-4">
            <TabsTrigger
              value="pending"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Pending <Badge className="ml-2 bg-red-500">{filteredPendingEmails.length}</Badge>
            </TabsTrigger>
            <TabsTrigger
              value="tasks"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Tasks <Badge className="ml-2 bg-amber-500">{pendingTasks.length}</Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="animate-in fade-in-50 duration-300">
            <div className="space-y-4">
              {filteredPendingEmails.length > 0 ? (
                filteredPendingEmails.map((email) => (
                  <div
                    key={email.id}
                    className="flex items-start space-x-4 p-3 border rounded-md bg-card hover:bg-accent/50 transition-colors duration-200"
                  >
                    <Avatar className="h-10 w-10 border">
                      <AvatarImage src={email.avatar} alt={email.from} />
                      <AvatarFallback>{email.from.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{email.from}</h4>
                        <div className="flex items-center">
                          <Badge variant="outline" className={`mr-2 ${getPriorityColor(email.priority)}`}>
                            {email.priority}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{email.time}</span>
                        </div>
                      </div>
                      <p className="text-sm font-medium">{email.subject}</p>
                      <p className="text-xs text-muted-foreground line-clamp-1">{email.preview}</p>

                      {/* Display extracted tasks if any */}
                      {email.extractedTasks && email.extractedTasks.length > 0 && (
                        <div className="mt-3 space-y-2">
                          <div className="text-xs font-medium text-muted-foreground flex items-center">
                            <Brain className="h-3 w-3 mr-1 text-purple-500" />
                            LLM-Extracted Tasks & Commitments
                          </div>
                          {email.extractedTasks.map((task) => (
                            <div key={task.id} className="bg-muted/50 p-2 rounded-md text-xs">
                              <div className="flex items-start justify-between">
                                <div className="flex items-start">
                                  {getTaskTypeIcon(task.type)}
                                  <span>{task.text}</span>
                                </div>
                                <div className="flex items-center">
                                  {task.confidence && (
                                    <Badge variant="outline" className="mr-1 text-[10px]">
                                      {Math.round(task.confidence * 100)}% confidence
                                    </Badge>
                                  )}
                                  <Badge variant="outline" className="text-[10px]">
                                    {task.status === "pending" ? `Due: ${task.dueDate}` : task.status}
                                  </Badge>
                                </div>
                              </div>

                              {task.status === "pending" && (
                                <div className="flex items-center mt-2 space-x-1">
                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-6 w-6 rounded-full hover:bg-green-100 hover:text-green-600 dark:hover:bg-green-900/30"
                                          onClick={() => completeTask(email.id, task.id)}
                                        >
                                          <Check className="h-3 w-3" />
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <p>Mark as completed</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>

                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-6 w-6 rounded-full hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-blue-900/30"
                                          onClick={() => scheduleTask(email.id, task.id)}
                                        >
                                          <Calendar className="h-3 w-3" />
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <p>Schedule for {task.suggestedTime}</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>

                                  <TooltipProvider>
                                    <Tooltip>
                                      <TooltipTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          size="icon"
                                          className="h-6 w-6 rounded-full hover:bg-purple-100 hover:text-purple-600 dark:hover:bg-purple-900/30"
                                          onClick={() => delegateTask(email.id, task.id)}
                                        >
                                          <UserPlus className="h-3 w-3" />
                                        </Button>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                        <p>Delegate task</p>
                                      </TooltipContent>
                                    </Tooltip>
                                  </TooltipProvider>
                                </div>
                              )}

                              {task.status === "scheduled" && (
                                <div className="mt-1 text-[10px] text-muted-foreground">
                                  Scheduled for {task.suggestedTime}
                                  {task.addedToCalendar && " • Added to calendar"}
                                </div>
                              )}

                              {task.status === "delegated" && task.assignedTo && (
                                <div className="mt-1 text-[10px] text-muted-foreground">
                                  Delegated to {task.assignedTo}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex mt-2 space-x-2">
                        {email.needsReply && (
                          <Badge variant="outline" className="text-red-500 border-red-500">
                            <Clock className="mr-1 h-3 w-3" />
                            Needs Reply
                          </Badge>
                        )}
                        {email.hasTasks && (
                          <Badge variant="outline" className="text-blue-500 border-blue-500">
                            <Clock className="mr-1 h-3 w-3" />
                            Has Tasks
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col space-y-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => markAsCompleted(email.id)}
                        className="h-8 w-8 p-0 rounded-full hover:bg-green-100 hover:text-green-600 dark:hover:bg-green-900/30"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0 rounded-full hover:bg-amber-100 hover:text-amber-600 dark:hover:bg-amber-900/30"
                      >
                        <Star className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0 rounded-full hover:bg-blue-100 hover:text-blue-600 dark:hover:bg-blue-900/30"
                      >
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  {filter !== "all" ? (
                    <>No {filter} priority emails pending. Try changing the filter.</>
                  ) : (
                    <>No pending emails. You're all caught up!</>
                  )}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="tasks" className="animate-in fade-in-50 duration-300">
            <div className="space-y-6">
              {/* Pending Tasks Section */}
              <div>
                <h3 className="text-sm font-medium mb-2 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-1 text-amber-500" />
                  Pending Tasks ({pendingTasks.length})
                </h3>
                {pendingTasks.length > 0 ? (
                  <div className="space-y-2">
                    {pendingTasks.map((task) => (
                      <div key={task.id} className="p-2 border rounded-md bg-amber-50/50 dark:bg-amber-900/10">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center">
                              <p className="text-sm font-medium">{task.text}</p>
                              {task.confidence && (
                                <Badge variant="outline" className="ml-2 text-[10px]">
                                  {Math.round(task.confidence * 100)}% confidence
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground flex items-center">
                              <Brain className="h-3 w-3 mr-1 text-purple-500" />
                              Extracted from: {task.emailFrom} • {task.emailSubject}
                            </p>
                          </div>
                          <Badge variant="outline" className="text-amber-500 border-amber-500">
                            Due: {task.dueDate}
                          </Badge>
                        </div>
                        <div className="flex items-center mt-2 space-x-1">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 text-xs rounded-full"
                            onClick={() => scheduleTask(task.emailId, task.id)}
                          >
                            <Calendar className="h-3 w-3 mr-1" />
                            Schedule ({task.suggestedTime})
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 text-xs rounded-full"
                            onClick={() => delegateTask(task.emailId, task.id)}
                          >
                            <UserPlus className="h-3 w-3 mr-1" />
                            Delegate
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7 text-xs rounded-full"
                            onClick={() => completeTask(task.emailId, task.id)}
                          >
                            <Check className="h-3 w-3 mr-1" />
                            Complete
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground text-sm">No pending tasks</div>
                )}
              </div>

              {/* Scheduled Tasks Section */}
              <div>
                <h3 className="text-sm font-medium mb-2 flex items-center">
                  <Calendar className="h-4 w-4 mr-1 text-blue-500" />
                  Scheduled Tasks ({scheduledTasks.length})
                </h3>
                {scheduledTasks.length > 0 ? (
                  <div className="space-y-2">
                    {scheduledTasks.map((task) => (
                      <div key={task.id} className="p-2 border rounded-md bg-blue-50/50 dark:bg-blue-900/10">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="text-sm font-medium">{task.text}</p>
                            <p className="text-xs text-muted-foreground flex items-center">
                              <Brain className="h-3 w-3 mr-1 text-purple-500" />
                              Scheduled for: {task.suggestedTime}
                            </p>
                          </div>
                          <Badge variant="outline" className="text-blue-500 border-blue-500">
                            {task.addedToCalendar ? "In Calendar" : "Scheduled"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground text-sm">No scheduled tasks</div>
                )}
              </div>

              {/* Delegated Tasks Section */}
              <div>
                <h3 className="text-sm font-medium mb-2 flex items-center">
                  <UserPlus className="h-4 w-4 mr-1 text-purple-500" />
                  Delegated Tasks ({delegatedTasks.length})
                </h3>
                {delegatedTasks.length > 0 ? (
                  <div className="space-y-2">
                    {delegatedTasks.map((task) => (
                      <div key={task.id} className="p-2 border rounded-md bg-purple-50/50 dark:bg-purple-900/10">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="text-sm font-medium">{task.text}</p>
                            <p className="text-xs text-muted-foreground flex items-center">
                              <Brain className="h-3 w-3 mr-1 text-purple-500" />
                              Delegated to: {task.assignedTo}
                            </p>
                          </div>
                          <Badge variant="outline" className="text-purple-500 border-purple-500">
                            Awaiting
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-muted-foreground text-sm">No delegated tasks</div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

